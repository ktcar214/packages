import pyrad
import os

pyrad  # keep pyflakes happy
home = os.path.dirname(os.path.realpath(__file__))
