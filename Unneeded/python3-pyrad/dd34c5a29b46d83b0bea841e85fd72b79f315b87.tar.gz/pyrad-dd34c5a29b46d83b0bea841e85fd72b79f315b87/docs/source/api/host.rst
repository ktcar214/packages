:mod:`pyrad.host` -- RADIUS host definition
===========================================

.. automodule:: pyrad.host

  .. autoclass:: Host
    :members:
